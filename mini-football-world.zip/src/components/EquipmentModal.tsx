import React, { useState } from 'react';
import { Check, X } from 'lucide-react';
import {
  BALL_CATALOG,
  BOOT_CATALOG,
  CELEBRATION_CATALOG,
  CREST_CATALOG,
  KIT_CATALOG,
} from '../game/catalog';
import type { CelebrationId, UserProgress } from '../game/types';

interface EquipmentModalProps {
  progress: UserProgress;
  onUpdateProgress: (next: UserProgress) => void;
  onClose: () => void;
}

export const ClubCrestSvg: React.FC<{
  primary: string;
  accent: string;
  shape: 'shield' | 'diamond' | 'crest' | 'crown';
  className?: string;
}> = ({ primary, accent, shape, className = 'h-9 w-9' }) => (
  <svg viewBox="0 0 48 48" className={className} aria-hidden="true">
    {shape === 'diamond' ? (
      <polygon points="24,4 44,24 24,44 4,24" fill={primary} stroke={accent} strokeWidth="3" />
    ) : shape === 'crown' ? (
      <path d="M8 14 L16 24 L24 10 L32 24 L40 14 L38 38 L10 38 Z" fill={primary} stroke={accent} strokeWidth="3" />
    ) : (
      <path d="M10 8 L24 4 L38 8 L36 30 C34 38 24 44 24 44 C24 44 14 38 12 30 Z" fill={primary} stroke={accent} strokeWidth="3" />
    )}
    <circle cx="24" cy="24" r="7" fill="#FFFFFF" stroke="#0F172A" strokeWidth="2" />
  </svg>
);

export const EquipmentModal: React.FC<EquipmentModalProps> = ({
  progress,
  onUpdateProgress,
  onClose,
}) => {
  const [tab, setTab] = useState<'kits' | 'crests' | 'gear' | 'celebrations'>('kits');
  const [kitSearch, setKitSearch] = useState('');

  const filteredKits = KIT_CATALOG.filter((k) =>
    k.name.toLowerCase().includes(kitSearch.toLowerCase())
  );

  const handleUnlockOrEquip = (
    id: string,
    cost: number,
    field: 'kitId' | 'crestId' | 'ballId' | 'bootId' | 'celebrationId'
  ) => {
    const unlocked = progress.unlockedIds.includes(id);
    if (unlocked) {
      onUpdateProgress({ ...progress, [field]: id });
      return;
    }
    if (progress.coins < cost) return;
    onUpdateProgress({
      ...progress,
      coins: progress.coins - cost,
      unlockedIds: [...progress.unlockedIds, id],
      [field]: id,
    });
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4" style={{ backgroundColor: 'rgba(6, 10, 20, 0.85)' }}>
      <div className="flex max-h-[88vh] w-full max-w-4xl flex-col rounded-2xl border border-white/15 bg-[#11192B] shadow-2xl">
        <div className="shrink-0 flex items-center justify-between border-b border-white/10 px-6 py-4">
          <div>
            <h2 className="font-display text-2xl font-extrabold tracking-wide text-white">
              Equipment & Club Customization
            </h2>
            <div className="text-xs text-slate-300 tabular-nums">
              {progress.coins.toLocaleString()} Coins · Kits, Club Logos, Balls, Boots & Goal Celebrations
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Equipment"
            className="rounded-lg border border-white/15 p-2 text-slate-300 hover:bg-slate-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="shrink-0 flex gap-2 border-b border-white/10 px-6 py-3 overflow-x-auto">
          {[
            { id: 'kits', label: `Kits (${KIT_CATALOG.length})` },
            { id: 'crests', label: `Logos & Crests (${CREST_CATALOG.length})` },
            { id: 'gear', label: 'Balls & Boots' },
            { id: 'celebrations', label: 'Celebrations' },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id as typeof tab)}
              className={`rounded-lg px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                tab === item.id ? 'bg-emerald-500 text-slate-950' : 'bg-slate-900 text-slate-300 hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="custom-scroll flex-1 overflow-y-auto p-6">
          {tab === 'kits' && (
            <div>
              <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                <div className="text-xs text-slate-300">
                  Showing {filteredKits.length} of {KIT_CATALOG.length} unlockable club kits
                </div>
                <input
                  type="text"
                  value={kitSearch}
                  onChange={(e) => setKitSearch(e.target.value)}
                  placeholder="Search kits (e.g. Cobalt, Stripes, Madrid)..."
                  className="rounded-lg border border-white/15 bg-slate-900 px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:border-emerald-400 focus:outline-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 md:grid-cols-4">
                {filteredKits.map((kit) => {
                  const unlocked = progress.unlockedIds.includes(kit.id);
                  const equipped = progress.kitId === kit.id;
                  return (
                    <button
                      key={kit.id}
                      type="button"
                      onClick={() => handleUnlockOrEquip(kit.id, kit.unlockCostCoins, 'kitId')}
                      className={`flex flex-col items-start rounded-xl border p-3 text-left transition-colors ${
                        equipped ? 'border-emerald-400 bg-emerald-500/15' : 'border-white/10 bg-slate-900 hover:border-white/25'
                      }`}
                    >
                      <div className="flex w-full items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <span className="h-5 w-5 rounded border border-white/25" style={{ backgroundColor: kit.primary }} />
                          <span className="h-5 w-5 rounded border border-white/25" style={{ backgroundColor: kit.secondary }} />
                        </div>
                        {equipped && <Check className="h-4 w-4 text-emerald-400" />}
                      </div>
                      <div className="mt-2 text-xs font-semibold text-white truncate w-full">{kit.name}</div>
                      <div className="mt-0.5 text-[11px] text-slate-400 tabular-nums">
                        {equipped ? 'Equipped' : unlocked ? 'Owned · Tap to Equip' : `${kit.unlockCostCoins} Coins`}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {tab === 'crests' && (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              {CREST_CATALOG.map((crest) => {
                const unlocked = progress.unlockedIds.includes(crest.id);
                const equipped = progress.crestId === crest.id;
                return (
                  <button
                    key={crest.id}
                    type="button"
                    onClick={() => handleUnlockOrEquip(crest.id, crest.unlockCostCoins, 'crestId')}
                    className={`flex items-center gap-3 rounded-xl border p-4 text-left transition-colors ${
                      equipped ? 'border-amber-400 bg-amber-400/15' : 'border-white/10 bg-slate-900 hover:border-white/25'
                    }`}
                  >
                    <ClubCrestSvg primary={crest.primary} accent={crest.accent} shape={crest.shape} className="h-11 w-11 shrink-0" />
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-white truncate">{crest.name}</div>
                      <div className="mt-0.5 text-[11px] text-slate-400 tabular-nums">
                        {equipped ? 'Equipped Crest' : unlocked ? 'Owned · Tap to Equip' : `${crest.unlockCostCoins} Coins`}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}

          {tab === 'gear' && (
            <div className="space-y-6">
              <div>
                <h3 className="font-display text-lg font-bold text-white">Match Balls</h3>
                <div className="mt-2 grid grid-cols-2 gap-2.5 sm:grid-cols-3">
                  {BALL_CATALOG.map((ball) => {
                    const unlocked = progress.unlockedIds.includes(ball.id);
                    const equipped = progress.ballId === ball.id;
                    return (
                      <button
                        key={ball.id}
                        type="button"
                        onClick={() => handleUnlockOrEquip(ball.id, ball.unlockCostCoins, 'ballId')}
                        className={`flex items-center justify-between rounded-xl border p-3 text-left ${
                          equipped ? 'border-emerald-400 bg-emerald-500/15' : 'border-white/10 bg-slate-900'
                        }`}
                      >
                        <div>
                          <div className="text-xs font-semibold text-white">{ball.name}</div>
                          <div className="text-[11px] text-slate-400 tabular-nums">
                            {equipped ? 'Equipped' : unlocked ? 'Owned' : `${ball.unlockCostCoins} Coins`}
                          </div>
                        </div>
                        <span className="h-6 w-6 rounded-full border-2 border-white/30" style={{ backgroundColor: ball.primary }} />
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <h3 className="font-display text-lg font-bold text-white">Boots & Speed Cleats</h3>
                <div className="mt-2 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                  {BOOT_CATALOG.map((boot) => {
                    const unlocked = progress.unlockedIds.includes(boot.id);
                    const equipped = progress.bootId === boot.id;
                    return (
                      <button
                        key={boot.id}
                        type="button"
                        onClick={() => handleUnlockOrEquip(boot.id, boot.unlockCostCoins, 'bootId')}
                        className={`rounded-xl border p-3 text-left ${
                          equipped ? 'border-emerald-400 bg-emerald-500/15' : 'border-white/10 bg-slate-900'
                        }`}
                      >
                        <div className="text-xs font-semibold text-white">{boot.name}</div>
                        <div className="mt-1 text-[11px] text-emerald-400">+{boot.paceBonus} Pace</div>
                        <div className="mt-1 text-[11px] text-slate-400 tabular-nums">
                          {equipped ? 'Equipped' : unlocked ? 'Owned' : `${boot.unlockCostCoins} Coins`}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {tab === 'celebrations' && (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {CELEBRATION_CATALOG.map((cel) => {
                const unlocked = progress.unlockedIds.includes(cel.id);
                const equipped = progress.celebrationId === cel.id;
                return (
                  <button
                    key={cel.id}
                    type="button"
                    onClick={() => handleUnlockOrEquip(cel.id as CelebrationId, cel.unlockCostCoins, 'celebrationId')}
                    className={`rounded-xl border p-4 text-left ${
                      equipped ? 'border-amber-400 bg-amber-400/15' : 'border-white/10 bg-slate-900'
                    }`}
                  >
                    <div className="text-sm font-bold text-white">{cel.name}</div>
                    <div className="mt-0.5 text-xs text-slate-400">{cel.description}</div>
                    <div className="mt-2 text-xs font-semibold text-amber-300 tabular-nums">
                      {equipped ? 'Equipped' : unlocked ? 'Owned · Tap to Equip' : `${cel.unlockCostCoins} Coins`}
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
